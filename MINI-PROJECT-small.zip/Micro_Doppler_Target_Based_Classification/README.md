# Micro-Doppler Target Classification

This project focuses on classifying micro-Doppler radar signatures of aerial targets like drones and birds using Convolutional Neural Networks (CNNs).

## Project Structure
```
.
├── models/              # Trained models
├── notebooks/           # Jupyter notebooks for EDA and experiments
├── src/
│   ├── data/            # Data loading and generation
│   ├── features/        # Feature extraction (e.g., spectrograms)
│   ├── models/          # Model definitions and training
│   └── utils/           # Utility functions
├── data/
│   ├── raw/             # Raw data (e.g., combined_microdoppler.csv)
│   ├── processed/       # Preprocessed data for modeling
│   └── interim/         # Intermediate transformation outputs
```

## Setup
```bash
pip install numpy pandas tensorflow matplotlib scikit-learn
```

## Usage
1. Generate or load data in `src/data/`.
2. Extract features using `src/features/`.
3. Train or evaluate models in `src/models/`.